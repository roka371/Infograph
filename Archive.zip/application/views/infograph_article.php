<!--
Article view for Infograph that shows a single article in a fullscreen view.
-->